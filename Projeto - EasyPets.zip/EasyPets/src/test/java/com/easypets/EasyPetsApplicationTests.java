package com.easypets;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EasyPetsApplicationTests {

	@Test
	void contextLoads() {
	}

}
